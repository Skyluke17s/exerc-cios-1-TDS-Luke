#include <stdio.h>
int geracoes;
int coelho = 1;
int coelhoAnt = 1;

int main(){
    printf("quantas gerações deseja?\n");
    scanf("%d", &geracoes);
    
    for(int geracao = 1; geracao <= geracoes; geracao++){
        printf("geração atual: %d --- quantia de coelhos: %d\n", geracao, coelho);
        coelhoAnt = coelhoAnt * 2;
        coelho = coelhoAnt * 2 - 1;
    }
}