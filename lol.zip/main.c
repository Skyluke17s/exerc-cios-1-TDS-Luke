#include <stdio.h>
int linhat;
int asterisco = 1;

int main() {
	printf("digite um numero inteiro");
	scanf("%d",&linhat);
	for(int linhas = 0; linhas<= linhat; linhas++) {
		for(int espaco = 0; espaco <= linhat - linhas ; espaco++) {
			printf(" ");
		}
		for(int asterisco = 1 ; asterisco <= linhas * 2 - 1 ; asterisco++) {
			printf("*");
		}
		printf ("\n");
	}
}